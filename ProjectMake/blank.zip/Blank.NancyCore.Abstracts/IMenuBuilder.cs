﻿using Blank.NancyCore.Abstract.DataModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Blank.NancyCore.Abstract
{
    public interface IMenuBuilder
    {
        MainMenu GetMenu();
    }
}
